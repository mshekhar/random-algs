import threading

print_sync_lock = threading.Lock()
