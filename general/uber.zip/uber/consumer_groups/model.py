class ConsumerGroup(object):
    def __init__(self):
        self.name = None
        self.consumers = []



