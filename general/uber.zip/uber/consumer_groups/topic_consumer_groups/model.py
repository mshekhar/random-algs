class TopicConsumerGroup(object):
    def __init__(self):
        self.topic = None
        self.consumer_group = None
        self.offset = None
